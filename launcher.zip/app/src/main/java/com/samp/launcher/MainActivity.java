package com.samp.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.ViewGroup;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    static class Server {
        String name, host, info = "";
        int port;
        Server(String n, String h, int p) { name = n; host = h; port = p; }
        String addr() { return host + ":" + port; }
        @Override public String toString() {
            return name + "\n" + addr() + (info.isEmpty() ? "" : "   " + info);
        }
    }

    SharedPreferences sp;
    FrameLayout content;
    final Handler ui = new Handler(Looper.getMainLooper());

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }
    void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_LONG).show(); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("launcher", MODE_PRIVATE);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(8), dp(36), dp(8), dp(8));
        LinearLayout tabs = new LinearLayout(this);
        String[] names = {"Hosted", "Избранное", "Добавить", "Настройки"};
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            Button t = new Button(this);
            t.setText(names[i]);
            t.setAllCaps(false);
            t.setTextSize(12);
            t.setOnClickListener(v -> show(idx));
            tabs.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        content = new FrameLayout(this);
        root.addView(tabs);
        root.addView(content, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
        show(0);
    }

    void show(int i) {
        content.removeAllViews();
        if (i == 0) showHosted();
        else if (i == 1) showFavs();
        else if (i == 2) showAdd();
        else showSettings();
    }

    // ---------- Hosted ----------
    void showHosted() {
        final ArrayList<Server> items = new ArrayList<>();
        final ArrayAdapter<Server> ad = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, items);
        ListView lv = new ListView(this);
        lv.setAdapter(ad);
        lv.setOnItemClickListener((p, v, pos, id) -> hostedDialog(items.get(pos)));
        content.addView(lv);
        new Thread(() -> {
            final List<Server> res = loadHosted();
            ui.post(() -> {
                items.clear();
                items.addAll(res);
                ad.notifyDataSetChanged();
            });
        }).start();
    }

    List<Server> loadHosted() {
        List<Server> r = new ArrayList<>();
        String json = null;
        String url = sp.getString("hosted_url", "").trim();
        if (!url.isEmpty()) {
            try { json = readAll(openUrl(url)); } catch (Exception e) { json = null; }
        }
        if (json == null) {
            try { json = readAll(getAssets().open("hosted.json")); } catch (Exception e) { return r; }
        }
        try {
            JSONArray a = new JSONArray(json);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Server s = new Server(o.optString("name", "Server"), o.optString("host"), o.optInt("port", 7777));
                if (o.has("players")) s.info = o.optInt("players") + "/" + o.optInt("max");
                r.add(s);
            }
        } catch (Exception e) { }
        return r;
    }

    InputStream openUrl(String u) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(8000);
        return c.getInputStream();
    }

    String readAll(InputStream in) throws IOException {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
        in.close();
        return o.toString("UTF-8");
    }

    void hostedDialog(final Server s) {
        new AlertDialog.Builder(this).setTitle(s.name)
            .setItems(new String[]{"Играть", "В избранное"}, (d, w) -> {
                if (w == 0) play(s); else addFav(s);
            }).show();
    }

    // ---------- Избранное ----------
    List<Server> loadFavs() {
        List<Server> r = new ArrayList<>();
        String raw = sp.getString("favs", "");
        for (String line : raw.split("\n")) {
            String[] p = line.split("\t");
            if (p.length == 3) {
                try { r.add(new Server(p[0], p[1], Integer.parseInt(p[2]))); } catch (Exception e) { }
            }
        }
        return r;
    }

    void saveFavs(List<Server> l) {
        StringBuilder sb = new StringBuilder();
        for (Server s : l) {
            sb.append(s.name.replace("\t", " ").replace("\n", " ")).append('\t')
              .append(s.host).append('\t').append(s.port).append('\n');
        }
        sp.edit().putString("favs", sb.toString()).apply();
    }

    void addFav(Server s) {
        List<Server> l = loadFavs();
        for (Server x : l) {
            if (x.host.equals(s.host) && x.port == s.port) { toast("Уже в избранном"); return; }
        }
        l.add(s);
        saveFavs(l);
        toast("Добавлено в избранное");
    }

    void showFavs() {
        final List<Server> items = loadFavs();
        if (items.isEmpty()) {
            TextView t = new TextView(this);
            t.setText("Избранных серверов пока нет");
            t.setPadding(dp(16), dp(16), dp(16), dp(16));
            content.addView(t);
            return;
        }
        ListView lv = new ListView(this);
        lv.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, items));
        lv.setOnItemClickListener((p, v, pos, id) -> favDialog(items.get(pos)));
        content.addView(lv);
    }

    void favDialog(final Server s) {
        new AlertDialog.Builder(this).setTitle(s.name)
            .setItems(new String[]{"Играть", "Удалить"}, (d, w) -> {
                if (w == 0) {
                    play(s);
                } else {
                    List<Server> keep = new ArrayList<>();
                    for (Server x : loadFavs()) {
                        if (!(x.host.equals(s.host) && x.port == s.port)) keep.add(x);
                    }
                    saveFavs(keep);
                    show(1);
                }
            }).show();
    }

    // ---------- Добавить ----------
    LinearLayout col() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(8), dp(8), dp(8), dp(8));
        return l;
    }

    EditText edit(String hint, String value) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(value);
        e.setSingleLine(true);
        return e;
    }

    Server readServer(EditText n, EditText h, EditText p) {
        String host = h.getText().toString().trim();
        if (host.isEmpty()) { toast("Введи адрес сервера"); return null; }
        int port = 7777;
        try { port = Integer.parseInt(p.getText().toString().trim()); } catch (Exception e) { }
        String name = n.getText().toString().trim();
        return new Server(name.isEmpty() ? host : name, host, port);
    }

    void showAdd() {
        ScrollView sv = new ScrollView(this);
        LinearLayout l = col();
        final EditText n = edit("Название", "");
        final EditText h = edit("IP или домен", "");
        final EditText p = edit("Порт", "7777");
        p.setInputType(InputType.TYPE_CLASS_NUMBER);
        Button fav = new Button(this);
        fav.setText("Добавить в избранное");
        Button go = new Button(this);
        go.setText("Играть");
        fav.setOnClickListener(v -> {
            Server s = readServer(n, h, p);
            if (s != null) addFav(s);
        });
        go.setOnClickListener(v -> {
            Server s = readServer(n, h, p);
            if (s != null) play(s);
        });
        l.addView(n);
        l.addView(h);
        l.addView(p);
        l.addView(fav);
        l.addView(go);
        sv.addView(l);
        content.addView(sv);
    }

    // ---------- Настройки ----------
    void showSettings() {
        ScrollView sv = new ScrollView(this);
        LinearLayout l = col();
        final EditText nick = edit("Ник", sp.getString("nick", "Player"));
        final EditText pkg = edit("Пакет игры (например com.xxx.samp)", sp.getString("pkg", ""));
        final EditText url = edit("URL списка Hosted (JSON, необязательно)", sp.getString("hosted_url", ""));
        final CheckBox monet = new CheckBox(this);
        monet.setText("monetloader");
        monet.setChecked(sp.getBoolean("monet", false));
        final CheckBox cleo = new CheckBox(this);
        cleo.setText("CLEO");
        cleo.setChecked(sp.getBoolean("cleo", false));
        Button save = new Button(this);
        save.setText("Сохранить");
        save.setOnClickListener(v -> {
            sp.edit()
                .putString("nick", nick.getText().toString().trim())
                .putString("pkg", pkg.getText().toString().trim())
                .putString("hosted_url", url.getText().toString().trim())
                .putBoolean("monet", monet.isChecked())
                .putBoolean("cleo", cleo.isChecked())
                .apply();
            toast("Сохранено");
        });
        l.addView(nick);
        l.addView(pkg);
        l.addView(url);
        l.addView(monet);
        l.addView(cleo);
        l.addView(save);
        sv.addView(l);
        content.addView(sv);
    }

    // ---------- Запуск игры ----------
    void play(Server s) {
        String nick = sp.getString("nick", "Player");
        String pkg = sp.getString("pkg", "").trim();
        if (pkg.isEmpty()) { toast("Укажи пакет игры в настройках"); show(3); return; }
        String ini = "host=" + s.host + "\nport=" + s.port + "\nnick=" + nick
            + "\nmonetloader=" + (sp.getBoolean("monet", false) ? 1 : 0)
            + "\ncleo=" + (sp.getBoolean("cleo", false) ? 1 : 0) + "\n";
        writeIni(new File(getExternalFilesDir(null), "samp_settings.ini"), ini);
        boolean ok = writeIni(new File("/sdcard/Android/data/" + pkg + "/files/samp_settings.ini"), ini);
        Intent it = getPackageManager().getLaunchIntentForPackage(pkg);
        if (it == null) { toast("Игра не найдена: " + pkg); return; }
        it.putExtra("host", s.host);
        it.putExtra("port", s.port);
        it.putExtra("nick", nick);
        if (!ok) toast("Не удалось записать конфиг в папку игры (Android блокирует доступ)");
        startActivity(it);
    }

    boolean writeIni(File f, String text) {
        try {
            File d = f.getParentFile();
            if (d != null) d.mkdirs();
            FileOutputStream o = new FileOutputStream(f);
            o.write(text.getBytes("UTF-8"));
            o.close();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
